<?php

    include "./components/header.php";

    include "./components/page-header.php";

    include './components/breadcrumb.php';

    include './components/slider.php';

    include './components/widget-about.php';

    echo '<br><br><br><br><br><br><br><br><br><br><br><br><br><br>';
    
    include "./components/footer.php";

?>